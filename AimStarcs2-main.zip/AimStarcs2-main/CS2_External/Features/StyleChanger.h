#pragma once
#include "..\Utils\Style.h"

namespace StyleChanger
{
	void UpdateSkin(int Skin) noexcept;
}