#pragma once
#include "..\Resources\Language.h"

namespace ConfigMenu {
    void RenderConfigMenu(const char *Tab);
    void RenderCFGmenu();
    void ResetToDefault();
    // Define other configuration-related functions and variables here.
}
