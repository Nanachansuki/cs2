<h1 align="center">
  <img src="https://raw.githubusercontent.com/CowNowK/AimStar/master/AS_Logo.png" alt="icon" style="width: 100px; height: 100px"><br>
  AimStar
</h1>
<p align="center">
<a href="https://en.wikipedia.org/wiki/C%2B%2B"><img src="https://img.shields.io/badge/build-C++-blue?style=flat&label=Language&logo=visualstudio&logoColor=%231082c3"></a>
<a href="https://store.steampowered.com/app/730/CounterStrike_2"><img src="https://img.shields.io/badge/Game-CS2-red.svg?style=flat&logo=data:image/svg%2bxml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZlcnNpb249IjEiIHdpZHRoPSI2MDAiIGhlaWdodD0iNjAwIj48cGF0aCBkPSJNMTI5IDExMWMtNTUgNC05MyA2Ni05MyA3OEwwIDM5OGMtMiA3MCAzNiA5MiA2OSA5MWgxYzc5IDAgODctNTcgMTMwLTEyOGgyMDFjNDMgNzEgNTAgMTI4IDEyOSAxMjhoMWMzMyAxIDcxLTIxIDY5LTkxbC0zNi0yMDljMC0xMi00MC03OC05OC03OGgtMTBjLTYzIDAtOTIgMzUtOTIgNDJIMjM2YzAtNy0yOS00Mi05Mi00MmgtMTV6IiBmaWxsPSIjZmZmIi8+PC9zdmc+"></a>
<a href="https://github.com/CowNowK/AimStar/releases"><img src="https://img.shields.io/github/v/release/CowNowK/AimStar?color=orange&logoColor=orange&label=Download&logo=DocuSign"></a>
<a href="https://discord.com/invite/VgRrxwesPz"><img src="https://img.shields.io/discord/1179009716307886080?logo=discord&logoColor=%234ec920"></a>
</p>
<h4 align="center">
  ⛔ USE AT YOUR OWN RISK ⛔
</h4>

## ❗ Info

[**zxq你妈死了哈哈**](https://github.com/CowNowK/AimStar/blob/main/Guides/Resellers.md)

Free and open-source external cheat for CS2, written in C++. - Available for Windows8.1+

Discord server: [AimShit Club](https://discord.com/invite/VgRrxwesPz)

Most of the code is contributed by users, and the code structure might be very messy. If you try to download and understand the code, you will find a lot of **shitty** logic

中文文档：[Readme CN](https://github.com/CowNowK/AimStar/blob/main/%E8%87%AA%E8%BF%B0%E6%96%87%E6%A1%A3.md)

Русский язык: [Readme RU](https://github.com/CowNowK/AimStar/blob/main/ПРОЧИТАЙМЕНЯ.md)

## ⚠️ Notice

**Isnt working?** -> [**__COMMON ISSUES__**](https://github.com/CowNowK/AimStar/wiki)

***
> I am so busy that I may not update the code on time. If u have the capability to update or fix bugs, u can pull ur request🤩
***
## 📸 Preview
![](/Image2.png)

## 📋 Features

<details>
<summary>Visual</summary>
  
- ESP
- Glow
- Radar
- Crosshairs
- No Flash
</details>

<details>
<summary>Misc</summary>

- Bhop
- Aimbot
- Triggerbot
- Languages Settings
- Hit Sound
- Bomb Timer
</details>

## ⚠️ Disclamers
- 🚫 **The project is for learning purposes only and strictly prohibited for any illegal activities. Users bear full responsibility for any misuse.**
Please read the following advice carefully before using Aimstar.
<details> <summary>Some advice</summary>

- Aimstar is a hobby project, and it should be treated as such. The project aims to enhance the community's learning of process debugging and reverse engineering, and to demonstrate the potential of C++ programming on Windows systems. At the same time, we strongly oppose cheating in video games. If you use Aimstar to cheat, you will not only ruin the fairness and fun of the game, but also damage your own reputation and dignity.

- Cheating in video games may reflect your inner anxiety and dissatisfaction. You may feel that you are not good enough in the game, or that you are ridiculed and rejected by other players. You may hope to improve your game level and social status by cheating, or to bring yourself some happiness and sense of achievement. However, these are superficial and temporary, and cannot really solve your problem.

- Cheating will make you lose the challenge and fun of the game, as well as the respect and trust of other players. Cheating will make you fall into a false self-perception, and make you ignore your true strengths and potential. Cheating will make you miss the opportunity and process of improving yourself through hard work and learning.

- If you want to get rid of the temptation and consequences of cheating, you need to face your psychological state and motivation, and seek professional help and support. Communicating with a psychologist or counselor can help you find more healthy and effective coping strategies, and also help you build a more positive and confident self-image. You can also participate in some beneficial activities and social interactions, such as joining some game communities or clubs, making some like-minded friends, or trying some new games or interests.

- I hope you can recognize the harm and meaninglessness of cheating, and also hope you can enjoy the true fun and value of the game. I appreciate your interest and support for Aimstar, but I also hope you can abide by the rules and ethics of the game, and respect yourself and others. Thank you for your understanding and cooperation. 🙏
</details>

  
- Main code forked from [**__Liv__**](https://github.com/TKazer/CS2_External)
- Features copied from UnknownCheats
  - [Glow](https://www.unknowncheats.me/forum/counter-strike-2-a/604503-glow-external.html)
  - [Weapon Icon](https://www.unknowncheats.me/forum/counter-strike-2-a/608799-weapon-icon-esp.html)
  - [HitSound](https://www.unknowncheats.me/forum/counter-strike-2-releases/607417-hitsound-external.html)
- Features intergrated from [Aeonix](https://github.com/Fr0go1/Aeonix-Cs2)
  - Visible Check Box
  - Corner Box
  - Mouse Aimbot
- Major help from Shinyaluvs

## ⭐ Star History

[![Star History Chart](https://api.star-history.com/svg?repos=CowNowK/AimStar&type=Date)](https://star-history.com/#CowNowK/AimStar&Date)

## 💲 Best Resell

这个拼多多商家已经将免费的AimStar以35元永久的价格售出了10万份

![1f76f67174ee54af569f0ea8dc64963](https://github.com/CowNowK/AimStar/assets/133740174/f032647a-b648-4b9b-986e-3288e22d3d0f)
<details><summary>圈钱大蛇实名鉴赏</summary>
  
司晓鹏先生
![Screenshot_2024-02-29-02-38-04-598_com taobao idlefish](https://github.com/CowNowK/AimStar/assets/65479796/38e02274-bf54-471c-ac3e-b52450890424)
![Screenshot_2024-02-29-02-37-55-626_com taobao idlefish](https://github.com/CowNowK/AimStar/assets/65479796/0b0c2907-c956-4b76-bb2e-e25e5a5782af)

张海先生
![Screenshot_2024-02-29-02-43-07-667_com taobao idlefish](https://github.com/CowNowK/AimStar/assets/65479796/f1832d98-8381-4a1e-bd48-9323d4e0cc0b)
![Screenshot_2024-02-29-02-43-04-859_com taobao idlefish](https://github.com/CowNowK/AimStar/assets/65479796/5ca6e6c3-2ad0-4f0e-ab0b-71c828188699)

张国华先生
![Screenshot_2024-02-29-03-03-29-207_com taobao idlefish-edit](https://github.com/CowNowK/AimStar/assets/65479796/ed31b09c-8878-4ab7-8add-0f92a180aa3e)
![Screenshot_2024-02-29-03-03-40-673_com taobao idlefish-edit](https://github.com/CowNowK/AimStar/assets/65479796/a16fc131-7db4-40cc-a51a-76dbef9ef2c3)

</details>
