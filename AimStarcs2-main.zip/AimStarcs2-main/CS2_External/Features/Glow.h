#pragma once
#include "..\Entity.h"
#include "..\MenuConfig.hpp"

namespace Glow
{
	void Run(const CEntity& aLocalPlayer);
}